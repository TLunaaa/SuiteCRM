<?php 
 // created: 2019-09-04 06:53:44
$mod_strings['LBL_IDSISTEMAWEB'] = 'IDSistemaWeb';

?>
