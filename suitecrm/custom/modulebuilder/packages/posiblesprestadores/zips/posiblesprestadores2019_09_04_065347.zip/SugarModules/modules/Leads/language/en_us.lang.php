<?php 
 // created: 2019-09-04 06:53:44
$mod_strings['LNK_NEW_LEAD'] = 'Create Posible Prestador';
$mod_strings['LNK_LEAD_LIST'] = 'View Posibles Prestadores';
$mod_strings['LNK_IMPORT_VCARD'] = 'Create Posible Prestador From vCard';
$mod_strings['LNK_IMPORT_LEADS'] = 'Import Posibles Prestadores';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Posible Prestador List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Posible Prestador Search';
$mod_strings['LBL_REPORTS_TO'] = 'Reports To:';
$mod_strings['LBL_CONTACTS'] = 'Prestadores';
$mod_strings['LBL_ACCOUNT'] = 'Facturación';
$mod_strings['LBL_LEADS'] = 'Leads';
$mod_strings['LBL_OPPORTUNITIES'] = 'Especialidades por Prestador';
$mod_strings['LBL_LIST_MY_LEADS'] = 'My Posibles Prestadores';
$mod_strings['LBL_CONTACT_ID'] = 'Prestador ID';
$mod_strings['LBL_CONVERTED_CONTACT'] = 'Converted Prestador:';
$mod_strings['LBL_ACCOUNT_DESCRIPTION'] = 'Facturación Description';
$mod_strings['LBL_ACCOUNT_ID'] = 'Facturación ID';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Facturación Name:';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Facturación Name';
$mod_strings['LBL_CONVERTED_ACCOUNT'] = 'Converted Facturación:';
$mod_strings['LNK_SELECT_ACCOUNTS'] = ' OR Select Facturación';
$mod_strings['LNK_NEW_ACCOUNT'] = 'Create Facturación';
$mod_strings['LBL_OPPORTUNITY_AMOUNT'] = 'Especialidad por Prestador Amount:';
$mod_strings['LBL_OPPORTUNITY_ID'] = 'Especialidad por Prestador ID';
$mod_strings['LBL_OPPORTUNITY_NAME'] = 'Especialidad por Prestador Name:';
$mod_strings['LBL_CONVERTED_OPP'] = 'Converted Especialidad por Prestador:';
$mod_strings['LBL_LEAD_SOURCE'] = 'Posible Prestador Source:';
$mod_strings['LBL_LEAD_SOURCE_DESCRIPTION'] = 'Posible Prestador Source Description:';
$mod_strings['LBL_MODULE_NAME'] = 'Posibles Prestadores';

?>
