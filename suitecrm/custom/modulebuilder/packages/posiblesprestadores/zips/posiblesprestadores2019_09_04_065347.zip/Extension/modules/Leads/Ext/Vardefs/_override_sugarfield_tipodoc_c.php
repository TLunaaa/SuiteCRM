<?php
 // created: 2019-08-25 16:53:28
$dictionary['Lead']['fields']['tipodoc_c']['inline_edit']=1;

 ?>