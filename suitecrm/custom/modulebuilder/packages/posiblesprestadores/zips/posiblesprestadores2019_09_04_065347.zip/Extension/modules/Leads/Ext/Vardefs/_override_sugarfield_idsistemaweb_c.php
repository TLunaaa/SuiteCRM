<?php
 // created: 2019-09-04 06:48:13
$dictionary['Lead']['fields']['idsistemaweb_c']['inline_edit']='1';
$dictionary['Lead']['fields']['idsistemaweb_c']['labelValue']='IDSistemaWeb';

 ?>