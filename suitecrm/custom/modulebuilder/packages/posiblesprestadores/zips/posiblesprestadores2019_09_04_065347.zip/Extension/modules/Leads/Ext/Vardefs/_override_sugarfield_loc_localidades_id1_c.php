<?php
 // created: 2019-08-25 16:53:27
$dictionary['Lead']['fields']['loc_localidades_id1_c']['inline_edit']=1;

 ?>