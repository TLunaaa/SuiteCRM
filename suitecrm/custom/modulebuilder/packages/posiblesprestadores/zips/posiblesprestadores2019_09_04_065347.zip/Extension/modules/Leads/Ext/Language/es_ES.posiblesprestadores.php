<?php 
 // created: 2019-08-25 16:42:06
$mod_strings['LNK_NEW_LEAD'] = 'Nuevo Posible Prestador';
$mod_strings['LNK_LEAD_LIST'] = 'Ver Posibles Prestadores';
$mod_strings['LNK_IMPORT_VCARD'] = 'Nuevo Posible Prestador desde vCard';
$mod_strings['LNK_IMPORT_LEADS'] = 'Importar Posibles Prestadores';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Lista de Clientes Potenciales';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Búsqueda de Clientes Potenciales';
$mod_strings['LBL_REPORTS_TO'] = 'Reports To:';
$mod_strings['LBL_MODULE_NAME'] = 'Posibles Prestadores';
$mod_strings['LBL_OPPORTUNITIES'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITY_AMOUNT'] = 'Cantidad de la Especialidad por Prestador:';
$mod_strings['LBL_OPPORTUNITY_ID'] = 'ID Especialidad por Prestador';
$mod_strings['LBL_OPPORTUNITY_NAME'] = 'Nombre de la Especialidad por Prestador:';
$mod_strings['LBL_CONVERTED_OPP'] = 'Especialidad por Prestador Convertida:';
$mod_strings['LBL_NOMBRECALLE'] = 'Calle';
$mod_strings['LBL_NUMEROCALLE'] = 'Número';
$mod_strings['LBL_PISO'] = 'Piso';
$mod_strings['LBL_DEPTO'] = 'Dpto/Of/Local';
$mod_strings['LBL_CODPOSTAL'] = 'Cód. Postal';
$mod_strings['LBL_OBCDOMICILIO'] = 'Observaciones domicilio';
$mod_strings['LBL_PAIS_PAIS_PAISES_ID'] = '&#039;País&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_PAIS'] = 'País';
$mod_strings['LBL_PROVINCIA_PROV_PROVINCIAS_ID'] = '&#039;Provincia&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_PROVINCIA'] = 'Provincia';
$mod_strings['LBL_MUNICIPIO_MUNI_MUNICIPIOS_ID'] = '&#039;Municipio&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_MUNICIPIO'] = 'Municipio';
$mod_strings['LBL_LOCALIDAD_LOC_LOCALIDADES_ID'] = '&#039;Localidad&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_LOCALIDAD'] = 'Localidad';
$mod_strings['LBL_ESPECIALIDAD_ESPE_ESPECIALIDADES_ID'] = '&#039;Especialidad&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_ESPECIALIDAD'] = 'Especialidad';
$mod_strings['LBL_PAISPRESTACION_PAIS_PAISES_ID'] = '&#039;País Prestación&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_PAISPRESTACION'] = 'País Prestación';
$mod_strings['LBL_PROVINCIAPRESTACION_PROV_PROVINCIAS_ID'] = '&#039;Provincia Prestación&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_PROVINCIAPRESTACION'] = 'Provincia Prestación';
$mod_strings['LBL_MUNICIPIOPRESTACION_MUNI_MUNICIPIOS_ID'] = '&#039;Municipio Prestación&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_MUNICIPIOPRESTACION'] = 'Municipio Prestación';
$mod_strings['LBL_LOCALIDADPRESTACION_LOC_LOCALIDADES_ID'] = '&#039;Localidad Prestación&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_LOCALIDADPRESTACION'] = 'Localidad Prestación';
$mod_strings['LBL_TIPODOC'] = 'Tipo Documento';
$mod_strings['LBL_NRODOC'] = 'Nro Documento';
$mod_strings['LBL_NROMATRICULA'] = 'Nro Matrícula';
$mod_strings['LBL_CONTACT_INFORMATION'] = 'Datos Personales';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Domicilio';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Posible Prestación';

?>
