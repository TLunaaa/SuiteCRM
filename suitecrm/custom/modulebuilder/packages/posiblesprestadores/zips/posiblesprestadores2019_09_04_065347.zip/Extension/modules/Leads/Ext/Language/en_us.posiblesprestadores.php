<?php 
 // created: 2019-08-25 16:42:06
$mod_strings['LBL_REPORTS_TO'] = 'Reports To:';
$mod_strings['LBL_CONTACTS'] = 'Prestadores';
$mod_strings['LBL_LEADS'] = 'Leads';
$mod_strings['LBL_CONTACT_ID'] = 'Prestador ID';
$mod_strings['LBL_CONVERTED_CONTACT'] = 'Converted Prestador:';
$mod_strings['LBL_ACCOUNT'] = 'Facturación';
$mod_strings['LBL_ACCOUNT_DESCRIPTION'] = 'Facturación Description';
$mod_strings['LBL_ACCOUNT_ID'] = 'Facturación ID';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Facturación Name:';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Facturación Name';
$mod_strings['LBL_CONVERTED_ACCOUNT'] = 'Converted Facturación:';
$mod_strings['LNK_SELECT_ACCOUNTS'] = ' OR Select Facturación';
$mod_strings['LNK_NEW_ACCOUNT'] = 'Create Facturación';

?>
