<?php
 // created: 2019-08-25 16:53:27
$dictionary['Lead']['fields']['localidad_c']['inline_edit']=1;

 ?>