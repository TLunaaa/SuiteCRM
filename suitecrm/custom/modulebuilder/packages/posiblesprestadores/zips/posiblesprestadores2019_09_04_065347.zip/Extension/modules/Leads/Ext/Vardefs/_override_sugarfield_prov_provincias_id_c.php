<?php
 // created: 2019-08-25 16:53:28
$dictionary['Lead']['fields']['prov_provincias_id_c']['inline_edit']=1;

 ?>