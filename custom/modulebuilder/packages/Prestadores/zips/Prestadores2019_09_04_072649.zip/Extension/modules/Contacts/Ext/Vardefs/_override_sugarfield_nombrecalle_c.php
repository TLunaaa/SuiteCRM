<?php
 // created: 2019-08-26 07:09:50
$dictionary['Contact']['fields']['nombrecalle_c']['inline_edit']=1;

 ?>