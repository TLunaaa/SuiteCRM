<?php
//auto-generated file DO NOT EDIT
$layout_defs['Contacts']['subpanel_setup']['leads']['override_subpanel_name'] = 'Contact_subpanel_leads';
?>