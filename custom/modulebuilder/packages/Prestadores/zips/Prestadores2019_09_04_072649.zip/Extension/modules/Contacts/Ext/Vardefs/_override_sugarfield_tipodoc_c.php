<?php
 // created: 2019-08-26 07:09:51
$dictionary['Contact']['fields']['tipodoc_c']['inline_edit']=1;

 ?>