<?php
 // created: 2019-09-04 07:01:02
$dictionary['Contact']['fields']['idsistemaweb_c']['inline_edit']='1';
$dictionary['Contact']['fields']['idsistemaweb_c']['labelValue']='IDSistemaWeb';

 ?>