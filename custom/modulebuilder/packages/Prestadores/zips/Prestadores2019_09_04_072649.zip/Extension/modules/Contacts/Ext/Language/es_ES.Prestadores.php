<?php 
 // created: 2019-08-26 06:58:41
$mod_strings['LBL_LEADS'] = 'Leads';
$mod_strings['LBL_LEADS_SUBPANEL_TITLE'] = 'Posibles Prestadores';
$mod_strings['LBL_OPPORTUNITIES'] = 'Opportunities';
$mod_strings['LBL_OPPORTUNITIES_SUBPANEL_TITLE'] = 'Especialidades por Prestador';
$mod_strings['LBL_OPPORTUNITY_ROLE'] = 'Rol en Especialidad por Prestador';
$mod_strings['LBL_OPPORTUNITY_ROLE_ID'] = 'ID de Rol en Especialidad por Prestador';
$mod_strings['LBL_DOCUMENTS_SUBPANEL_TITLE'] = 'Documentos';
$mod_strings['LBL_NOMBRECALLE'] = 'Calle';
$mod_strings['LBL_NUMEROCALLE'] = 'Número';
$mod_strings['LBL_PISO'] = 'Piso';
$mod_strings['LBL_DEPTO'] = 'Dpto/Of/Local';
$mod_strings['LBL_CODPOSTAL'] = 'Cód. Postal';
$mod_strings['LBL_OBSDOMICILIO'] = 'Observaciones Domicilio';
$mod_strings['LBL_PAIS_PAIS_PAISES_ID'] = '&#039;País&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_PAIS'] = 'País';
$mod_strings['LBL_PROVINCIA_PROV_PROVINCIAS_ID'] = '&#039;Provincia&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_PROVINCIA'] = 'Provincia';
$mod_strings['LBL_MUNICIPIO_MUNI_MUNICIPIOS_ID'] = '&#039;Municipio&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_MUNICIPIO'] = 'Municipio';
$mod_strings['LBL_LOCALIDAD_LOC_LOCALIDADES_ID'] = '&#039;Localidad&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_LOCALIDAD'] = 'Localidad';
$mod_strings['LBL_TIPODOC'] = 'Tipo Documento';
$mod_strings['LBL_NRODOC'] = 'Nro. Documento';
$mod_strings['LBL_NACIONALIDAD_NACI_NACIONALIDADES_ID'] = '&#039;Nacionalidad&#039; (relacionado &#039;&#039; ID)';
$mod_strings['LBL_NACIONALIDAD'] = 'Nacionalidad';
$mod_strings['LBL_FNACIMIENTO'] = 'Fecha Nacimiento';
$mod_strings['LBL_REFERIDOPOR_CONTACT_ID'] = '&#039;Referido por&#039; (relacionado &#039;Prestador&#039; ID)';
$mod_strings['LBL_REFERIDOPOR'] = 'Referido por';
$mod_strings['LBL_ESTADO_PRESTADOR'] = 'Estado Prestador';
$mod_strings['LBL_OBSESTADO'] = 'Observaciones Estado';
$mod_strings['LBL_MAPA_PRESTADOR'] = 'mapa prestador';
$mod_strings['LBL_ORIGENBAJA'] = 'Origen Baja';
$mod_strings['LBL_MOTIVOBAJA'] = 'Motivo Baja';
$mod_strings['LBL_FECHABAJA'] = 'Fecha Baja';
$mod_strings['LBL_NOTASBAJA'] = 'Notas Baja';
$mod_strings['LBL_MOTIVOCANCELACION'] = 'Motivo Cancelación';
$mod_strings['LBL_NOTASCANCELACION'] = 'Notas Cancelación';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Facturación:';
$mod_strings['LBL_CONTACT_INFORMATION'] = 'Datos Personales';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'Domicilio';
$mod_strings['LBL_EDITVIEW_PANEL2'] = 'Datos sobre la baja';
$mod_strings['LBL_EDITVIEW_PANEL3'] = 'Datos sobre la cancelación';
$mod_strings['LBL_CONTACTS_OPPORTUNITIES_1_FROM_OPPORTUNITIES_TITLE'] = 'Especialidades Habilitadas';

?>
