<?php 
 // created: 2019-08-26 06:58:41
$mod_strings['LBL_PROSPECT_LIST'] = 'Persona List';
$mod_strings['LNK_NEW_CONTACT'] = 'Create Prestador';
$mod_strings['LNK_CONTACT_LIST'] = 'View Prestadores';
$mod_strings['LNK_IMPORT_VCARD'] = 'Create Prestador From vCard';
$mod_strings['LNK_IMPORT_CONTACTS'] = 'Import Prestadores';
$mod_strings['LBL_SAVE_CONTACT'] = 'Save Prestador';
$mod_strings['LBL_LIST_FORM_TITLE'] = 'Prestador List';
$mod_strings['LBL_SEARCH_FORM_TITLE'] = 'Prestador Search';
$mod_strings['LBL_REPORTS_TO'] = 'Reports To:';
$mod_strings['LBL_DIRECT_REPORTS'] = 'Direct Reports';
$mod_strings['LBL_DIRECT_REPORTS_SUBPANEL_TITLE'] = 'Direct Reports';
$mod_strings['LBL_HOMEPAGE_TITLE'] = 'My Prestadores';
$mod_strings['LBL_MODULE_NAME'] = 'Prestadores';
$mod_strings['LBL_ACCOUNT_NAME'] = 'Facturación Name:';
$mod_strings['LBL_ACCOUNT_ID'] = 'Facturación ID:';
$mod_strings['LBL_ACCOUNT'] = 'Facturación';
$mod_strings['LBL_LIST_ACCOUNT_NAME'] = 'Facturación Name';
$mod_strings['LBL_DOCUMENTS_SUBPANEL_TITLE'] = 'Documentaciónación';

?>
