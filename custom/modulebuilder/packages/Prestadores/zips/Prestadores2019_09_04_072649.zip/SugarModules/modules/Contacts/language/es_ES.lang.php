<?php 
 // created: 2019-09-04 07:26:45
$mod_strings['LBL_LEADS_SUBPANEL_TITLE'] = 'Posibles Prestadores';
$mod_strings['LBL_IDSISTEMAWEB'] = 'IDSistemaWeb';

?>
